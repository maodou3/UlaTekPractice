local _, addon = ...
local sim = { width = 120, height = 74, duration = 61, separation = 3 }
addon.sim = sim

sim.rounds = {
    { opens = 3, closes = 14, slam = { 23, 27 }, firstSide = 1 },
    { opens = 33, closes = 40, slam = { 52, 57 }, firstSide = 2 },
}
sim.soaks = { { 37, 59 }, { 83, 59 } }
sim.soakRadius = 10
sim.bubbleRadius = 10
sim.bubbles = {
    { at = 20, x = 37, y = 59 },
    { at = 30.5, x = 60, y = 48 },
    { at = 35, x = 60, y = 37 },
    { at = 60, x = 60, y = 59 },
}
sim.waves = {}
local function volley(at, axis, direction, lanes, rebounds)
    for _, lane in ipairs(lanes) do
        sim.waves[#sim.waves + 1] = { at, axis, direction, lane, rebounds }
    end
end

-- These patterns are authored for practice. Positions use training yards.
volley(10, "y", 1, { 12, 31, 52, 73, 95, 113 })
volley(13, "y", 1, { 6, 22, 43, 63, 85, 106 })
volley(12, "x", 1, { 13, 34, 54, 70 }, true)
volley(25, "x", -1, { 8, 24, 43, 64 }, true)
volley(30, "y", 1, { 15, 38, 58, 78, 99, 116 })
volley(38, "y", 1, { 8, 28, 48, 68, 88, 109 })
volley(41, "y", 1, { 18, 38, 58, 78, 98, 119 })
volley(41, "x", -1, { 10, 29, 48, 67 }, true)
volley(47, "x", 1, { 15, 35, 55, 73 }, true)
volley(50, "y", 1, { 12, 31, 51, 71, 91, 111 })
volley(53, "x", -1, { 7, 25, 42, 62 }, true)

local function distance2(x, y, a, b)
    return (x - a)^2 + (y - b)^2
end

function sim.egg(slot)
    return 39 + ((slot - 1) % 4) * 14, slot <= 4 and 32 or 43
end

function sim.wavePosition(wave, t)
    local at, axis, direction, lane, rebounds = unpack(wave)
    local limit = axis == "x" and sim.width or sim.height
    local travel = (t - at) * 16 - 5
    if t < at - 1.3 or travel > (rebounds and 2 * limit or limit) + 6 then return end
    local returning = rebounds and travel >= limit or false
    local position = returning and 2 * limit - travel or travel
    if direction == -1 then position = limit - position end
    if t < at then position = direction == 1 and 1 or limit - 1 end
    if axis == "x" then return position, lane, t >= at, returning end
    return lane, position, t >= at, returning
end

function sim.new(count)
    local game = { time = -3, players = {} }
    for slot = 1, count do
        local x, y = sim.egg(slot)
        game.players[slot] = { x = x, y = y + (slot <= 4 and -8 or 8), state = 0, score = 0, faults = 0, reason = 0 }
    end
    return game
end

local function fail(p, reason)
    p.state, p.faults, p.reason = 3, p.faults + 1, reason
end

function sim.step(game, dt, inputs)
    local previous = game.time
    game.time = math.min(sim.duration, previous + dt)
    local t = game.time
    if t < 0 or previous >= sim.duration then return end
    local round = t < 32 and sim.rounds[1] or sim.rounds[2]
    local reset = previous < 32 and t >= 32
    local hit = {}
    for slot, p in ipairs(game.players) do
        if reset then p.state = 0 end
        local mask = inputs[slot] or 0
        local dx = math.floor(mask / 2) % 2 - mask % 2
        local dy = math.floor(mask / 8) % 2 - math.floor(mask / 4) % 2
        local speed = (dx ~= 0 and dy ~= 0) and 7 / math.sqrt(2) or 7
        p.x = math.max(2, math.min(sim.width - 2, p.x + dx * speed * dt))
        p.y = math.max(2, math.min(sim.height - 2, p.y + dy * speed * dt))
        if p.state == 0 then
            local x, y = sim.egg(slot)
            if t >= round.closes then
                fail(p, 3)
            elseif t >= round.opens and distance2(p.x, p.y, x, y) <= 2.5^2 then
                p.state = 1
            end
        end
        if p.state == 1 then
            for _, wave in ipairs(sim.waves) do
                local x, y, active, returning = sim.wavePosition(wave, t)
                if active then
                    local rx = wave[2] == "x" and 4.6 or 2.4
                    local ry = wave[2] == "x" and 2.4 or 4.6
                    if ((p.x - x) / rx)^2 + ((p.y - y) / ry)^2 <= 1 then
                        hit[slot] = returning and 6 or 1
                        break
                    end
                end
            end
        end
    end
    for i, p in ipairs(game.players) do
        if p.state == 1 then
            for j = i + 1, #game.players do
                local q = game.players[j]
                if q.state == 1 and distance2(p.x, p.y, q.x, q.y) < sim.separation^2 then
                    hit[i], hit[j] = hit[i] or 2, hit[j] or 2
                end
            end
        end
    end
    for _, bubble in ipairs(sim.bubbles) do
        if previous < bubble.at and t >= bubble.at then
            for _, p in ipairs(game.players) do
                if distance2(p.x, p.y, bubble.x, bubble.y) > sim.bubbleRadius^2 then
                    p.faults, p.reason = p.faults + 1, 5
                end
            end
        end
    end
    for i, p in ipairs(game.players) do
        if hit[i] then
            fail(p, hit[i])
        elseif p.state == 1 then
            for index, slam in ipairs(round.slam) do
                if previous < slam and t >= slam then
                    local side = index == 1 and round.firstSide or 3 - round.firstSide
                    local soak = sim.soaks[side]
                    if distance2(p.x, p.y, soak[1], soak[2]) <= sim.soakRadius^2 then
                        p.state, p.score = 2, p.score + 1
                        break
                    end
                end
            end
            if p.state == 1 and t >= round.slam[2] then fail(p, 4) end
        end
    end
end
