local _, addon = ...
local sim = { width = 120, height = 74, duration = 61, separation = 3 }
addon.sim = sim

local rounds = {
    { opens = 3, closes = 14, slam = { 23, 27 } },
    { opens = 33, closes = 40, slam = { 52, 57 } },
}
sim.soaks = { { 37, 59 }, { 83, 59 } }
sim.soakRadius = 10
sim.bubbleRadius = 10

-- Each entry preserves the paired observations from one replay.
-- The board keeps the boss at the top so left and right match the raid's view.
sim.profiles = {
    { tail = { 2, 1 }, firstWing = { 2, 1 } },
    { tail = { 2, 2 }, firstWing = { 1, 1 } },
    { tail = { 1, 2 }, firstWing = { 1, 2 } },
}

local function wingRow(waves, at, side)
    local sign = side == 1 and -1 or 1
    for offset = 5, 46, 8 do
        waves[#waves + 1] = {
            at = at, x = sim.width / 2 + sign * offset, y = sim.height - 1 - offset * 0.4,
            vx = sign * 2.5, vy = -13,
        }
    end
end

local function spectralRow(waves, at, edge, lanes)
    local isFlank = edge ~= 3
    for _, lane in ipairs(lanes) do
        waves[#waves + 1] = {
            at = at, x = isFlank and (edge == 1 and 2 or sim.width - 2) or lane,
            y = isFlank and lane or 2,
            vx = isFlank and (edge == 1 and 16 or -16) or 0,
            vy = isFlank and 0 or 13,
            spectral = true,
        }
    end
end

local flankLanes = { 5, 15, 27, 37, 49, 61, 70 }
local function waveSequence(profile)
    local waves = {}
    spectralRow(waves, 19, 3 - profile.tail[1], flankLanes)
    for round, at in ipairs({ 26, 41 }) do
        local first = profile.firstWing[round]
        wingRow(waves, at, first)
        spectralRow(waves, at + 2.6, 3, { 10, 25, 39, 54, 68, 83, 97, 112 })
        wingRow(waves, at + 5, 3 - first)
        spectralRow(waves, at + 8, 1, { 10, 23, 40, 54, 69 })
        spectralRow(waves, at + 9, 2, { 4, 17, 31, 47, 63 })
    end
    return waves
end

local function distance2(x, y, a, b)
    return (x - a)^2 + (y - b)^2
end

function sim.egg(slot)
    return 39 + ((slot - 1) % 4) * 14, slot <= 4 and 32 or 43
end

function sim.wavePosition(wave, t)
    local elapsed = t - wave.at
    if elapsed < -1.3 then return end
    local travel = math.max(0, elapsed)
    local x, y = wave.x + travel * wave.vx, wave.y + travel * wave.vy
    if x < -5 or x > sim.width + 5 or y < -5 or y > sim.height + 5 then return end
    return x, y, elapsed >= 0
end

function sim.waveRadii(wave)
    if wave.vx ~= 0 and wave.vy == 0 then return 4.6, 2.4 end
    return 2.4, 4.6
end

function sim.new(count, profileId)
    profileId = profileId or 1
    local profile = sim.profiles[profileId]
    local game = {
        time = -3, players = {}, profileId = profileId, tail = profile.tail,
        waves = waveSequence(profile), rounds = {},
        bubbles = {
            { at = 20, x = sim.soaks[profile.tail[1]][1], y = 59 },
            { at = 30.5, x = 60, y = 48 },
            { at = 35, x = 60, y = 37 },
            { at = 60, x = 60, y = 59 },
        },
    }
    for index, round in ipairs(rounds) do
        game.rounds[index] = {
            opens = round.opens, closes = round.closes, slam = round.slam, firstSide = profile.tail[index],
        }
    end
    for slot = 1, count do
        local x, y = sim.egg(slot)
        game.players[slot] = { x = x, y = y + (slot <= 4 and -8 or 8), state = 0, score = 0, faults = 0, reason = 0 }
    end
    return game
end

local function fail(p, reason)
    p.state, p.faults, p.reason = 3, p.faults + 1, reason
end

function sim.step(game, dt, inputs)
    local previous = game.time
    game.time = math.min(sim.duration, previous + dt)
    local t = game.time
    if t < 0 or previous >= sim.duration then return end
    local round = t < 32 and game.rounds[1] or game.rounds[2]
    local reset = previous < 32 and t >= 32
    local hit = {}
    for slot, p in ipairs(game.players) do
        if reset then p.state = 0 end
        local mask = inputs[slot] or 0
        local dx = math.floor(mask / 2) % 2 - mask % 2
        local dy = math.floor(mask / 8) % 2 - math.floor(mask / 4) % 2
        local speed = (dx ~= 0 and dy ~= 0) and 7 / math.sqrt(2) or 7
        p.x = math.max(2, math.min(sim.width - 2, p.x + dx * speed * dt))
        p.y = math.max(2, math.min(sim.height - 2, p.y + dy * speed * dt))
        if p.state == 0 then
            local x, y = sim.egg(slot)
            if t >= round.closes then
                fail(p, 3)
            elseif t >= round.opens and distance2(p.x, p.y, x, y) <= 2.5^2 then
                p.state = 1
            end
        end
        if p.state == 1 then
            for _, wave in ipairs(game.waves) do
                local x, y, active = sim.wavePosition(wave, t)
                if active then
                    local rx, ry = sim.waveRadii(wave)
                    if ((p.x - x) / rx)^2 + ((p.y - y) / ry)^2 <= 1 then
                        hit[slot] = wave.spectral and 6 or 1
                        break
                    end
                end
            end
        end
    end
    for i, p in ipairs(game.players) do
        if p.state == 1 then
            for j = i + 1, #game.players do
                local q = game.players[j]
                if q.state == 1 and distance2(p.x, p.y, q.x, q.y) < sim.separation^2 then
                    hit[i], hit[j] = hit[i] or 2, hit[j] or 2
                end
            end
        end
    end
    for _, bubble in ipairs(game.bubbles) do
        if previous < bubble.at and t >= bubble.at then
            for _, p in ipairs(game.players) do
                if distance2(p.x, p.y, bubble.x, bubble.y) > sim.bubbleRadius^2 then
                    p.faults, p.reason = p.faults + 1, 5
                end
            end
        end
    end
    for i, p in ipairs(game.players) do
        if hit[i] then
            fail(p, hit[i])
        elseif p.state == 1 then
            for index, slam in ipairs(round.slam) do
                if previous < slam and t >= slam then
                    local side = index == 1 and round.firstSide or 3 - round.firstSide
                    local soak = sim.soaks[side]
                    if distance2(p.x, p.y, soak[1], soak[2]) <= sim.soakRadius^2 then
                        p.state, p.score = 2, p.score + 1
                        break
                    end
                end
            end
            if p.state == 1 and t >= round.slam[2] then fail(p, 4) end
        end
    end
end
