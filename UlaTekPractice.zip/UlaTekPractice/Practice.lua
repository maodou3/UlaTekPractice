local _, addon = ...
local sim = addon.sim
local prefix = "UlaTekP1v3"
local reasons = { "持蛋中波", "持蛋相撞", "超时未拾蛋", "错过分摊", "漏进大怪气泡", "持蛋撞上幻影蛇尾波" }
local colors = {
    {0.25, 0.81, 1}, {1, 0.64, 0.36}, {0.78, 0.62, 1}, {0.35, 0.95, 0.72},
    {1, 0.54, 0.72}, {0.94, 0.86, 0.43}, {0.57, 0.69, 1}, {0.94, 0.94, 0.94},
}
local frame = CreateFrame("Frame", "UlaTekPracticeFrame", UIParent, "BackdropTemplate")
frame:SetSize(776, 570)
frame:SetPoint("CENTER")
frame:SetFrameStrata("DIALOG")
frame:SetClampedToScreen(true)
frame:SetMovable(true)
frame:EnableMouse(true)
frame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
frame:SetBackdropColor(0.054, 0.073, 0.082, 0.98)
frame:SetBackdropBorderColor(0.23, 0.34, 0.36, 1)

local function label(parent, font, point, x, y)
    local fs = parent:CreateFontString(nil, "OVERLAY", font)
    fs:SetPoint(point, parent, point, x, y)
    fs:SetJustifyH("LEFT")
    return fs
end

local title = label(frame, "GameFontNormalLarge", "TOPLEFT", 20, -17)
title:SetText("乌拉特克  /  史诗 P1 搬蛋练习")
local subtitle = label(frame, "GameFontHighlightSmall", "TOPLEFT", 20, -41)
subtitle:SetText("WASD / 方向键移动    ·    踩蛋拾取    ·    琥珀色是幻影蛇尾波    ·    紫色是大怪气泡    ·    蓝色是分摊")
local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
close:SetPoint("TOPRIGHT", -4, -4)
local drag = CreateFrame("Frame", nil, frame)
drag:SetPoint("TOPLEFT", 0, 0)
drag:SetSize(680, 39)
drag:EnableMouse(true)
drag:RegisterForDrag("LeftButton")
drag:SetScript("OnDragStart", function() frame:StartMoving() end)
drag:SetScript("OnDragStop", function() frame:StopMovingOrSizing() end)

local scale = 5.5
local board = CreateFrame("Frame", nil, frame)
board:SetSize(sim.width * scale, sim.height * scale)
board:SetPoint("TOP", 0, -65)
board:SetClipsChildren(true)
local floor = board:CreateTexture(nil, "BACKGROUND")
floor:SetAllPoints()
floor:SetColorTexture(0.10, 0.16, 0.17, 1)

local function mark(layer, sizeX, sizeY, circle)
    local tex = board:CreateTexture(nil, layer)
    tex:SetSize(sizeX * scale, sizeY * scale)
    if circle then
        tex:SetTexture("Interface\\AddOns\\UlaTekPractice\\Disc.tga")
    else
        tex:SetColorTexture(1, 1, 1, 1)
    end
    return tex
end

local function place(tex, x, y)
    tex:SetPoint("CENTER", board, "BOTTOMLEFT", x * scale, y * scale)
end

for x = 0, 120, 10 do
    local line = mark("BORDER", 0.14, sim.height)
    line:SetVertexColor(0.32, 0.51, 0.54, 0.20)
    place(line, x, sim.height / 2)
end
for y = 0, 70, 10 do
    local line = mark("BORDER", sim.width, 0.14)
    line:SetVertexColor(0.32, 0.51, 0.54, 0.20)
    place(line, sim.width / 2, y)
end

local boss = label(board, "GameFontDisableSmall", "TOP", 0, -5)
boss:SetText("乌拉特克 · 面朝上方")
local tailLabel = board:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
tailLabel:SetTextColor(0.8, 0.92, 0.49)
tailLabel:SetText("主蛇尾")
local timer = label(frame, "GameFontNormal", "TOPLEFT", 20, -485)
local details = label(frame, "GameFontHighlightSmall", "TOPLEFT", 20, -508)
local room = label(frame, "GameFontHighlightSmall", "BOTTOMLEFT", 20, 15)

local function button(text, offset, action)
    local b = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    b:SetSize(98, 24)
    b:SetPoint("BOTTOMRIGHT", offset, 10)
    b:SetText(text)
    b:SetScript("OnClick", action)
    return b
end

local eggs, players, waves, soaks = {}, {}, {}, {}
for slot = 1, 8 do
    local color = colors[slot]
    local x, y = sim.egg(slot)
    eggs[slot] = mark("ARTWORK", 2.9, 4, true)
    eggs[slot]:SetVertexColor(unpack(color))
    place(eggs[slot], x, y)
    local ring = mark("ARTWORK", sim.separation, sim.separation, true)
    local dot = mark("OVERLAY", 2, 2, true)
    local name = board:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    players[slot] = { dot = dot, ring = ring, name = name }
end
for i, wave in ipairs(sim.new(0).waves) do
    local rx, ry = sim.waveRadii(wave)
    waves[i] = mark("ARTWORK", rx * 2, ry * 2, true)
end
for i, point in ipairs(sim.soaks) do
    soaks[i] = mark("BORDER", sim.soakRadius * 2, sim.soakRadius * 2, true)
    place(soaks[i], unpack(point))
    local text = board:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    place(text, point[1], point[2] + 11)
    text:SetText(i == 1 and "左分摊" or "右分摊")
end

local bubbleArea = mark("BORDER", sim.bubbleRadius * 2, sim.bubbleRadius * 2, true)
local bubbleCenter = mark("ARTWORK", 2, 2, true)
local bubbleLabel = board:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
bubbleLabel:SetTextColor(0.92, 0.76, 1)
bubbleLabel:SetText("大怪气泡 · 集合")

local game, session, mySlot, channel, host, roster
local ready, candidates, keys, inputs, seen = false, {}, {}, {}, {}
local lastSend, lastPacket, lastTick, readyAt = 0, 0, -1, 0
local notice = "单人开练，或组队后让队员先点「准备联机」。"
local networkOK = C_ChatInfo.RegisterAddonMessagePrefix(prefix)

local function groupChannel()
    if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
    if IsInRaid() then return "RAID" end
    if IsInGroup() then return "PARTY" end
end

local function send(message)
    local route = groupChannel()
    if route and networkOK and not InCombatLockdown() then
        C_ChatInfo.SendAddonMessage(prefix, message, route)
    end
end

local function members()
    local byGuid, byName = {}, {}
    local function add(unit)
        local guid = UnitGUID(unit)
        local name, realm = UnitFullName(unit)
        if not guid or not name then return end
        if not realm or realm == "" then realm = GetNormalizedRealmName() end
        local fullName = name .. "-" .. realm
        byGuid[guid] = { name = name, leader = UnitIsGroupLeader(unit) }
        byName[fullName] = guid
        if realm == GetNormalizedRealmName() then byName[name] = guid end
    end
    add("player")
    local raid = IsInRaid()
    local count = raid and GetNumGroupMembers() or GetNumSubgroupMembers()
    for i = 1, count do add((raid and "raid" or "party") .. i) end
    return byGuid, byName
end

local function clear()
    game, session, mySlot, channel, host, roster = nil, nil, nil, nil, nil, nil
    keys, inputs, seen = {}, {}, {}
    lastTick = -1
end

local function enter(id, leader, list, route, profile)
    local own = UnitGUID("player")
    local myIndex
    for index, guid in ipairs(list) do
        if guid == own then myIndex = index end
    end
    if not myIndex then return end
    clear()
    session, host, roster, channel, mySlot = id, leader, list, route, myIndex
    game = sim.new(#roster, profile)
    lastSend, lastPacket = 0, GetTime()
end

local function mask()
    return ((keys.A or keys.LEFT) and 1 or 0)
        + ((keys.D or keys.RIGHT) and 2 or 0)
        + ((keys.S or keys.DOWN) and 4 or 0)
        + ((keys.W or keys.UP) and 8 or 0)
end

local function stopHosting()
    if channel and host == UnitGUID("player") then send("E:" .. session) end
end

button("单人开练", -326, function()
    stopHosting()
    ready = false
    local guid = UnitGUID("player")
    enter("solo", guid, {guid}, nil, math.random(#sim.profiles))
end)
local readyButton = button("准备联机", -221, function()
    if not groupChannel() or not networkOK or InCombatLockdown() then
        notice = "请在非战斗状态下加入小队或团队后再准备。"
        return
    end
    if channel and game and game.time < sim.duration then
        notice = "本局进行中，关闭窗口可退出。"
        return
    end
    ready = not ready
    send(ready and "R" or "U")
    readyAt = GetTime()
    notice = ready and "已准备，等待小队或团队队长开局。" or "已取消准备。"
end)
button("队长开局", -116, function()
    local route = groupChannel()
    if not route or not UnitIsGroupLeader("player") or not networkOK or InCombatLockdown() then
        notice = "请由小队或团队队长在非战斗状态下开局。"
        return
    end
    local memberList = members()
    local guid = UnitGUID("player")
    local participants = {}
    for candidate, received in pairs(candidates) do
        if candidate ~= guid and memberList[candidate] and GetTime() - received < 12 then
            participants[#participants + 1] = candidate
        end
    end
    table.sort(participants)
    if #participants == 0 or #participants > 7 then
        notice = "需要 1–7 名队员先点「准备联机」。"
        return
    end
    table.insert(participants, 1, guid)
    local id = tostring(math.random(100000, 999999))
    local profile = math.random(#sim.profiles)
    local packet = "B:" .. id .. ":" .. profile .. ":" .. table.concat(participants, ",")
    if #packet > 245 then
        notice = "队伍信息过长，请减少参与人数。"
        return
    end
    enter(id, guid, participants, route, profile)
    send(packet)
end)
button("结束 / 返回", -11, function()
    stopHosting()
    if ready then send("U") end
    ready = false
    clear()
    notice = "可重新单练，或由队长再次发起联机。"
end)

local function snapshot()
    local packed = {}
    for i, p in ipairs(game.players) do
        packed[i] = ("%03d%03d%d%d%d%d"):format(
            math.floor(p.x * 8 + 0.5), math.floor(p.y * 8 + 0.5), p.state, p.score, p.faults, p.reason)
    end
    send(("S:%s:%d:%s"):format(session, math.floor(game.time * 100 + 0.5), table.concat(packed)))
end

frame:RegisterEvent("CHAT_MSG_ADDON")
frame:RegisterEvent("PLAYER_REGEN_DISABLED")
frame:SetScript("OnEvent", function(self, event, incoming, message, distribution, sender)
    if event == "PLAYER_REGEN_DISABLED" then
        self:Hide()
        return
    end
    if not self:IsShown() or InCombatLockdown() then return end
    if issecretvalue and (issecretvalue(incoming) or issecretvalue(message)
        or issecretvalue(distribution) or issecretvalue(sender)) then return end
    if incoming ~= prefix or distribution ~= groupChannel() then return end
    local byGuid, byName = members()
    local guid = byName[sender]
    if not guid or guid == UnitGUID("player") then return end
    if message == "R" or message == "U" then
        candidates[guid] = message == "R" and GetTime() or nil
        return
    end

    local kind, id, data = message:match("^(%u):(%d+):?(.*)$")
    if kind == "B" and ready and byGuid[guid].leader then
        local profile, participants = data:match("^(%d+):(.+)$")
        profile = tonumber(profile)
        if not profile or not sim.profiles[profile] then return end
        local list, used = {}, {}
        for member in participants:gmatch("[^,]+") do
            if not byGuid[member] or used[member] or #list == 8 then return end
            used[member] = true
            list[#list + 1] = member
        end
        if list[1] == guid and #list >= 2 and id ~= session then
            enter(id, guid, list, distribution, profile)
        end
        return
    end
    if not channel or id ~= session then return end

    if kind == "I" and host == UnitGUID("player") then
        local value = tonumber(data)
        if not value or value < 0 or value > 15 or value % 1 ~= 0 then return end
        for slot, member in ipairs(roster) do
            if member == guid then
                inputs[slot], seen[slot] = value, GetTime()
                break
            end
        end
    elseif guid == host and kind == "E" then
        clear()
        notice = "队长已结束本局。"
    elseif guid == host and kind == "S" then
        local tick, packed = data:match("^(-?%d+):(%d+)$")
        tick = tonumber(tick)
        if not tick or tick < -300 or tick > sim.duration * 100 or tick < lastTick
            or #packed ~= #roster * 10 then return end
        for slot, p in ipairs(game.players) do
            local start = (slot - 1) * 10
            p.x = tonumber(packed:sub(start + 1, start + 3)) / 8
            p.y = tonumber(packed:sub(start + 4, start + 6)) / 8
            p.state = tonumber(packed:sub(start + 7, start + 7))
            p.score = tonumber(packed:sub(start + 8, start + 8))
            p.faults = tonumber(packed:sub(start + 9, start + 9))
            p.reason = tonumber(packed:sub(start + 10, start + 10))
        end
        game.time, lastTick, lastPacket = tick / 100, tick, GetTime()
    end
end)

local function render()
    local t = game and game.time or -3
    local roundIndex = t < 32 and 1 or 2
    local round = game and game.rounds[roundIndex]
    local nextSlam, activeSide
    tailLabel:SetShown(game ~= nil)
    if round then
        nextSlam = t < round.slam[1] and 1 or t < round.slam[2] and 2
        activeSide = nextSlam == 1 and round.firstSide or 3 - round.firstSide
        place(tailLabel, game.tail[roundIndex] == 1 and 8 or sim.width - 8, sim.height / 2)
    end
    for i, tex in ipairs(soaks) do
        local active = nextSlam and activeSide == i and round.slam[nextSlam] - t < 6
        tex:SetVertexColor(active and 0.28 or 0.27, active and 0.85 or 0.53, 0.93, active and 0.43 or 0.12)
    end
    local bubble
    if game then
        for _, candidate in ipairs(game.bubbles) do
            if t >= candidate.at - 4.5 and t < candidate.at + 0.35 then
                bubble = candidate
                break
            end
        end
    end
    bubbleArea:SetShown(bubble ~= nil)
    bubbleCenter:SetShown(bubble ~= nil)
    bubbleLabel:SetShown(bubble ~= nil)
    if bubble then
        place(bubbleArea, bubble.x, bubble.y)
        place(bubbleCenter, bubble.x, bubble.y)
        place(bubbleLabel, bubble.x, bubble.y - sim.bubbleRadius - 1.5)
        bubbleArea:SetVertexColor(0.75, 0.39, 1, t >= bubble.at and 0.65 or 0.36)
        bubbleCenter:SetVertexColor(0.89, 0.61, 1, 0.95)
    end
    for i, texture in ipairs(waves) do
        local wave = game and game.waves[i]
        local x, y, active
        if wave then x, y, active = sim.wavePosition(wave, t) end
        texture:SetShown(x ~= nil)
        if x then
            place(texture, x, y)
            if wave.spectral then
                if active then
                    texture:SetVertexColor(1, 0.64, 0.19, 0.95)
                else
                    texture:SetVertexColor(0.38, 0.95, 1, 0.55)
                end
            else
                texture:SetVertexColor(0.61, 1, 0.20, active and 0.90 or 0.37)
            end
        end
    end
    for i = 1, 8 do
        local marker = players[i]
        local p = game and game.players[i]
        local color = colors[i]
        marker.dot:SetShown(p ~= nil)
        marker.name:SetShown(p ~= nil)
        marker.ring:SetShown(p ~= nil and p.state == 1)
        eggs[i]:SetShown(p ~= nil and p.state == 0 and t >= 0 and t < round.closes)
        if p then
            eggs[i]:SetVertexColor(color[1], color[2], color[3], t >= round.opens and 1 or 0.30)
            marker.dot:SetVertexColor(color[1], color[2], color[3], p.state == 3 and 0.35 or 1)
            marker.ring:SetVertexColor(1, 0.92, 0.28, 0.55)
            place(marker.dot, p.x, p.y)
            place(marker.ring, p.x, p.y)
            place(marker.name, p.x, p.y + 2.7)
            marker.name:SetText(i == mySlot and "你" or tostring(i))
        end
    end
    readyButton:SetText(ready and "取消准备" or "准备联机")
    room:SetText(game and (channel and ("联机 · %d 人 · 你是 %d 号"):format(#roster, mySlot) or "单人练习") or "训练时间轴 · 约 1 分钟")
    if not game then
        timer:SetText("等待开练")
        details:SetText(notice)
        return
    end
    local p = game.players[mySlot]
    if t < 0 then
        timer:SetText(("开练倒计时  %d"):format(math.ceil(-t)))
    elseif t >= sim.duration then
        timer:SetText(("练习结束  ·  成功破蛋 %d / 2  ·  失误 %d"):format(p.score, p.faults))
    else
        local phase = ""
        if t < round.opens then
            phase = ("蛋壳 %.1f 秒后打开"):format(round.opens - t)
        elseif nextSlam then
            phase = ("%s分摊 %.1f 秒后落地"):format(activeSide == 1 and "左" or "右", round.slam[nextSlam] - t)
        end
        if bubble and t < bubble.at then
            local countdown = ("气泡集合 %.1f 秒"):format(bubble.at - t)
            phase = phase ~= "" and countdown .. "   /   " .. phase or countdown
        end
        timer:SetText(("%04.1f 秒   /   第 %d 轮   /   %s"):format(t, roundIndex, phase))
    end
    local state = ({ "移动到与你同色的蛋", "持蛋中", "本轮已破蛋", "本轮失败，可继续练走位" })[p.state + 1] or ""
    local recent = reasons[p.reason]
    details:SetText(state .. (recent and ("   ·   最近失误  " .. recent) or ""))
end

local acc = 0
frame:SetScript("OnUpdate", function(self, elapsed)
    local now = GetTime()
    if ready and now - readyAt >= 4 then
        send("R")
        readyAt = now
    end
    if game then
        if channel and channel ~= groupChannel() then
            clear()
            ready = false
            notice = "队伍已变更，本局结束。"
        elseif host == UnitGUID("player") then
            inputs[mySlot] = mask()
            for i = 2, #game.players do
                if now - (seen[i] or 0) > 0.9 then inputs[i] = 0 end
            end
            acc = acc + math.min(elapsed, 0.25)
            while acc >= 0.02 do
                sim.step(game, 0.02, inputs)
                acc = acc - 0.02
            end
            if channel and now - lastSend >= 0.14 then
                if game.time < sim.duration or now - (game.finishedAt or now) < 3 then snapshot() end
                if game.time >= sim.duration and not game.finishedAt then game.finishedAt = now end
                lastSend = now
            end
        elseif game.time < sim.duration and now - lastPacket > 5 then
            clear()
            notice = "与队长的同步已中断，请重新开局。"
        elseif now - lastSend >= 0.13 and game.time < sim.duration then
            send(("I:%s:%d"):format(session, mask()))
            lastSend = now
        end
    end
    render()
end)

local movement = { A = true, D = true, S = true, W = true, LEFT = true, RIGHT = true, UP = true, DOWN = true }
frame:EnableKeyboard(true)
frame:SetPropagateKeyboardInput(true)
frame:SetScript("OnKeyDown", function(self, key)
    local capture = game and game.time < sim.duration and movement[key] and not InCombatLockdown()
    self:SetPropagateKeyboardInput(not capture)
    if capture then keys[key] = true end
end)
frame:SetScript("OnKeyUp", function(self, key)
    local capture = keys[key]
    keys[key] = nil
    self:SetPropagateKeyboardInput(not capture)
end)
frame:SetScript("OnHide", function()
    stopHosting()
    if ready then send("U") end
    ready, candidates = false, {}
    clear()
end)
tinsert(UISpecialFrames, frame:GetName())
frame:Hide()

SLASH_ULATEKPRACTICE1 = "/ulap"
SLASH_ULATEKPRACTICE2 = "/ulatekpractice"
SlashCmdList.ULATEKPRACTICE = function()
    if InCombatLockdown() then
        print("乌拉特克练习：请脱战后打开。")
    elseif frame:IsShown() then
        frame:Hide()
    else
        frame:SetScale(math.min(1, UIParent:GetWidth() / 805, UIParent:GetHeight() / 600))
        render()
        frame:Show()
    end
end
